# سعراتي — مشروع أندرويد

تطبيق بسيط يتفتح فيه صفحة `app/src/main/assets/index.html` جوه WebView.
البيانات بتتخزن على الموبايل نفسه ومحتاجش نت.

## بناء الـ APK بدون كمبيوتر ولا Android Studio (GitHub)

1. اعمل حساب على github.com وأنشئ مستودع جديد (New repository).
2. ارفع محتويات المجلد ده كلها، ومعاها مجلد `.github` (Add file → Upload files).
3. افتح تبويب **Actions** واختار **Build APK** ثم **Run workflow**.
4. بعد ما يخلص (حوالي 3–5 دقايق) افتح التشغيل ونزّل **saaraty-apk** من Artifacts. جواه `app-debug.apk`.
5. افتح الملف على الموبايل واسمح بالتثبيت من مصدر غير معروف لما يسألك.

## بناء الـ APK من Android Studio

1. افتح المجلد ده من Android Studio (File → Open).
2. استنى الـ Gradle Sync يخلص.
3. Build → Build APK(s). الملف بيظهر في `app/build/outputs/apk/debug/`.

## ملاحظات

- لو شلت التطبيق من الموبايل، البيانات بتتمسح معاه.
- لتعديل شكل التطبيق أو سلوكه عدّل `app/src/main/assets/index.html`.
